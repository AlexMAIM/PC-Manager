﻿namespace proiect1
{
    partial class AddFurnizor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddFurnizor));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            btnCancel = new Button();
            cmbNume = new ComboBox();
            txtOras = new TextBox();
            txtAdresa = new TextBox();
            txtTelefon = new TextBox();
            txtEmail = new TextBox();
            txtCui = new TextBox();
            txtRating = new TextBox();
            dtpInregistrare = new DateTimePicker();
            sqlCommandBuilder1 = new Microsoft.Data.SqlClient.SqlCommandBuilder();
            btnAdauga = new Button();
            btnModify = new Button();
            btnDel = new Button();
            btnRefresh = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 24);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Nume";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 52);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 1;
            label2.Text = "Oraș";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 78);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 2;
            label3.Text = "Adresa";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 106);
            label4.Name = "label4";
            label4.Size = new Size(46, 15);
            label4.TabIndex = 3;
            label4.Text = "Telefon";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 134);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 4;
            label5.Text = "Email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 164);
            label6.Name = "label6";
            label6.Size = new Size(26, 15);
            label6.TabIndex = 5;
            label6.Text = "CUI";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 194);
            label7.Name = "label7";
            label7.Size = new Size(93, 15);
            label7.TabIndex = 6;
            label7.Text = "Data înregistrare";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 224);
            label8.Name = "label8";
            label8.Size = new Size(41, 15);
            label8.TabIndex = 7;
            label8.Text = "Rating";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(341, 373);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 8;
            btnCancel.Text = "Anulează";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // cmbNume
            // 
            cmbNume.FormattingEnabled = true;
            cmbNume.Location = new Point(140, 16);
            cmbNume.Name = "cmbNume";
            cmbNume.Size = new Size(206, 23);
            cmbNume.TabIndex = 9;
            // 
            // txtOras
            // 
            txtOras.Location = new Point(140, 44);
            txtOras.Name = "txtOras";
            txtOras.Size = new Size(206, 23);
            txtOras.TabIndex = 10;
            // 
            // txtAdresa
            // 
            txtAdresa.Location = new Point(140, 70);
            txtAdresa.Name = "txtAdresa";
            txtAdresa.Size = new Size(206, 23);
            txtAdresa.TabIndex = 11;
            // 
            // txtTelefon
            // 
            txtTelefon.Location = new Point(140, 98);
            txtTelefon.Name = "txtTelefon";
            txtTelefon.Size = new Size(206, 23);
            txtTelefon.TabIndex = 12;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(140, 126);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(206, 23);
            txtEmail.TabIndex = 13;
            // 
            // txtCui
            // 
            txtCui.Location = new Point(140, 156);
            txtCui.Name = "txtCui";
            txtCui.Size = new Size(206, 23);
            txtCui.TabIndex = 14;
            // 
            // txtRating
            // 
            txtRating.Location = new Point(140, 216);
            txtRating.Name = "txtRating";
            txtRating.Size = new Size(68, 23);
            txtRating.TabIndex = 15;
            // 
            // dtpInregistrare
            // 
            dtpInregistrare.Location = new Point(140, 185);
            dtpInregistrare.Name = "dtpInregistrare";
            dtpInregistrare.Size = new Size(206, 23);
            dtpInregistrare.TabIndex = 16;
            // 
            // btnAdauga
            // 
            btnAdauga.Location = new Point(12, 267);
            btnAdauga.Name = "btnAdauga";
            btnAdauga.Size = new Size(75, 23);
            btnAdauga.TabIndex = 17;
            btnAdauga.Text = "Adaugă";
            btnAdauga.UseVisualStyleBackColor = true;
            btnAdauga.Click += btnAdauga_Click;
            // 
            // btnModify
            // 
            btnModify.Location = new Point(12, 296);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(75, 23);
            btnModify.TabIndex = 18;
            btnModify.Text = "Modifică";
            btnModify.UseVisualStyleBackColor = true;
            btnModify.Click += btnModify_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(12, 325);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(75, 23);
            btnDel.TabIndex = 19;
            btnDel.Text = "Șterge";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Image = (Image)resources.GetObject("btnRefresh.Image");
            btnRefresh.Location = new Point(387, 8);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(29, 31);
            btnRefresh.TabIndex = 20;
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // AddFurnizor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Olive;
            ClientSize = new Size(428, 408);
            Controls.Add(btnRefresh);
            Controls.Add(btnDel);
            Controls.Add(btnModify);
            Controls.Add(btnAdauga);
            Controls.Add(dtpInregistrare);
            Controls.Add(txtRating);
            Controls.Add(txtCui);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefon);
            Controls.Add(txtAdresa);
            Controls.Add(txtOras);
            Controls.Add(cmbNume);
            Controls.Add(btnCancel);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddFurnizor";
            Text = "Adăugare Furnizor";
            Load += AddFurnizor_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Button btnCancel;
        private ComboBox cmbNume;
        private TextBox txtOras;
        private TextBox txtAdresa;
        private TextBox txtTelefon;
        private TextBox txtEmail;
        private TextBox txtCui;
        private TextBox txtRating;
        private DateTimePicker dtpInregistrare;
        private Microsoft.Data.SqlClient.SqlCommandBuilder sqlCommandBuilder1;
        private Button btnAdauga;
        private Button btnModify;
        private Button btnDel;
        private Button btnRefresh;
    }
}