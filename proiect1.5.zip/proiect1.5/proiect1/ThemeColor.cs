﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace proiect1
{
    internal class ThemeColor
    {
        public static Color PrimaryColor { get; set; }
        private static Random random = new Random();
        public static Color SecondaryColor { get; set; }
        public static List<string> ColorList = new List<string>
        { "#FF8000", "#F59536", "#D2761A", "#EBB57E" };
        public static int selectedIndex { get; set; } =
        random.Next(ThemeColor.ColorList.Count);

        public static Color ChangeColorBrightness(Color color, double correctionFactor)
        {
            double red = (double)color.R;
            double green = (double)color.G;
            double blue = (double)color.B;
            if (correctionFactor < 0)
            {
                correctionFactor = 1 + correctionFactor;
                red *= correctionFactor;
                green *= correctionFactor;
                blue *= correctionFactor;
            }
            else
            {
                red = (255 - red) * correctionFactor + red;
                green = (255 - green) * correctionFactor + green;
                blue = (255 - blue) * correctionFactor + blue;
            }
            return Color.FromArgb(color.A, (int)red, (int)green, (int)blue);
        }
        public static Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (index == selectedIndex)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            selectedIndex = index;

            string color = ColorList[selectedIndex];
            return ColorTranslator.FromHtml(color);
        }
        public static void LoadTheme(Form formActive)
        {
            foreach (Control control in formActive.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = PrimaryColor;
                    btn.ForeColor = Color.Black;
                    btn.FlatAppearance.BorderSize = 0;
                }
                if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = SecondaryColor;

                }
            }
        }

    }
}
