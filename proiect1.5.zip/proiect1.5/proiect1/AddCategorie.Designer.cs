﻿namespace proiect1
{
    partial class AddCategorie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCategorie));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnCancel = new Button();
            cmbNume = new ComboBox();
            txtDesc = new TextBox();
            dtpCreare = new DateTimePicker();
            txtActiv = new TextBox();
            btnAdd = new Button();
            btnModify = new Button();
            btnDel = new Button();
            btnRefresh = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = SystemColors.ActiveCaption;
            label1.Location = new Point(12, 34);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Nume";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaption;
            label2.Location = new Point(12, 65);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 1;
            label2.Text = "Descriere";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaption;
            label3.Location = new Point(12, 96);
            label3.Name = "label3";
            label3.Size = new Size(68, 15);
            label3.TabIndex = 2;
            label3.Text = "Data Creării";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ActiveCaption;
            label4.Location = new Point(12, 127);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 3;
            label4.Text = "Activ";
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(192, 0, 0);
            btnCancel.Location = new Point(241, 263);
            btnCancel.Margin = new Padding(0);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "Anulează";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // cmbNume
            // 
            cmbNume.FormattingEnabled = true;
            cmbNume.Location = new Point(93, 31);
            cmbNume.Name = "cmbNume";
            cmbNume.Size = new Size(200, 23);
            cmbNume.TabIndex = 5;
            cmbNume.SelectedIndexChanged += cmbNume_SelectedIndexChanged;
            // 
            // txtDesc
            // 
            txtDesc.Location = new Point(93, 62);
            txtDesc.Name = "txtDesc";
            txtDesc.Size = new Size(200, 23);
            txtDesc.TabIndex = 6;
            txtDesc.TextChanged += txtDesc_TextChanged;
            // 
            // dtpCreare
            // 
            dtpCreare.Location = new Point(93, 90);
            dtpCreare.Name = "dtpCreare";
            dtpCreare.Size = new Size(200, 23);
            dtpCreare.TabIndex = 7;
            dtpCreare.ValueChanged += dtpCreare_ValueChanged;
            // 
            // txtActiv
            // 
            txtActiv.Location = new Point(93, 124);
            txtActiv.Name = "txtActiv";
            txtActiv.Size = new Size(126, 23);
            txtActiv.TabIndex = 8;
            txtActiv.TextChanged += txtActiv_TextChanged;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(5, 196);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Adaugă";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnModify
            // 
            btnModify.Location = new Point(5, 254);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(75, 23);
            btnModify.TabIndex = 10;
            btnModify.Text = "Modifică";
            btnModify.UseVisualStyleBackColor = true;
            btnModify.Click += btnModify_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(5, 225);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(75, 23);
            btnDel.TabIndex = 11;
            btnDel.Text = "Șterge";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.Transparent;
            btnRefresh.Image = (Image)resources.GetObject("btnRefresh.Image");
            btnRefresh.Location = new Point(295, 2);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(30, 26);
            btnRefresh.TabIndex = 12;
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // AddCategorie
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(328, 298);
            Controls.Add(btnRefresh);
            Controls.Add(btnDel);
            Controls.Add(btnModify);
            Controls.Add(btnAdd);
            Controls.Add(txtActiv);
            Controls.Add(dtpCreare);
            Controls.Add(txtDesc);
            Controls.Add(cmbNume);
            Controls.Add(btnCancel);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddCategorie";
            Text = "Adăugare Categorie";
            Load += AddCategorie_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnCancel;
        private ComboBox cmbNume;
        private TextBox txtDesc;
        private DateTimePicker dtpCreare;
        private TextBox txtActiv;
        private Button btnAdd;
        private Button btnModify;
        private Button btnDel;
        private Button btnRefresh;
    }
}