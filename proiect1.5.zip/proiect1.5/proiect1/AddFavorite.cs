﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace proiect1
{
    public partial class AddFavorite : Form
    {
        private DataTable toatePiesele = new DataTable();  

        public AddFavorite()
        {
            InitializeComponent();
            cmbPiesa.SelectedIndexChanged += cmbPiesa_SelectedIndexChanged;
        }

        private void AddFavorite_Load(object sender, EventArgs e)
        {
            IncarcaToatePieseleInTextBox();
        }

        private void IncarcaToatePieseleInTextBox()
        {
            SqlConnection conn = Utilities.OpenDbConnection();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();

            try
            {
                conn.Open();
                string query = @"SELECT 
                                    p.id_piesa,
                                    p.nume_piesa,
                                    c.nume_categorie,
                                    p.favorit
                                 FROM Piese p
                                 INNER JOIN Categorii c ON p.id_categorie = c.id_categorie
                                 ORDER BY p.nume_piesa";

                cmd = new SqlCommand(query, conn);
                da.SelectCommand = cmd;
                toatePiesele.Clear();
                da.Fill(toatePiesele);

                cmbPiesa.DataSource = null;
                cmbPiesa.DataSource = toatePiesele;
                cmbPiesa.DisplayMember = "nume_piesa";
                cmbPiesa.ValueMember = "id_piesa";
                cmbPiesa.SelectedIndex = -1;
                cmbPiesa.Text = "Selectează o piesă";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea pieselor: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbPiesa.SelectedText) && string.IsNullOrWhiteSpace(cmbPiesa.Text))
            {
                MessageBox.Show("Selectează sau tastează numele unei piese din listă!");
                return;
            }

            string textSelectat = !string.IsNullOrEmpty(cmbPiesa.SelectedText)
                ? cmbPiesa.SelectedText.Trim()
                : cmbPiesa.Text.Trim();

            string numePiesaCautat = textSelectat.Split('(')[0].Trim();
            numePiesaCautat = numePiesaCautat.Replace("ok", "").Trim();

            DataRow[] rows = toatePiesele.Select($"nume_piesa LIKE '%{numePiesaCautat}%'");

            if (rows.Length == 0)
            {
                MessageBox.Show("Nu am găsit piesa specificată. Încearcă să selectezi exact numele din listă.");
                return;
            }

            if (rows.Length > 1)
            {
                MessageBox.Show("Sunt mai multe piese cu nume similar. Selectează exact una din listă.");
                return;
            }

            DataRow piesaGasita = rows[0];
            int idPiesa = Convert.ToInt32(piesaGasita["id_piesa"]);
            bool favoritActual = (bool)piesaGasita["favorit"];
            bool favoritNou = !favoritActual;  

            SqlConnection conn = Utilities.OpenDbConnection();
            try
            {
                conn.Open();
                string updateQuery = "UPDATE Piese SET favorit = @favorit WHERE id_piesa = @id";
                using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@favorit", favoritNou ? 1 : 0);
                    cmd.Parameters.AddWithValue("@id", idPiesa);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(favoritNou
                    ? $"Piesa \"{piesaGasita["nume_piesa"]}\" a fost adăugată la favorite!" 
                    : $"Piesa \"{piesaGasita["nume_piesa"]}\" a fost eliminată din favorite.");

                IncarcaToatePieseleInTextBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la modificarea favoritului: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void cmbPiesa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbPiesa.SelectedIndex > -1 && cmbPiesa.SelectedItem is DataRowView rowView)
            {
                string categorie = rowView["nume_categorie"].ToString();
                bool esteFavorit = (bool)rowView["favorit"];
                txtCategorie.Text = categorie;
                txtFavorit.Text = esteFavorit ? "Da" : "Nu";
            }
            else
            {
                txtCategorie.Text = "";
                txtFavorit.Text = "";
            }
        }

        private void txtFavorit_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtCategorie_TextChanged(object sender, EventArgs e)
        {
            string filtru = txtCategorie.Text.Trim().ToLower();


            foreach (DataRow row in toatePiesele.Rows)
            {
                string nume = row["nume_piesa"].ToString();
                string categorie = row["nume_categorie"].ToString().ToLower();
                bool esteFavorit = (bool)row["favorit"];

                if (string.IsNullOrEmpty(filtru) || categorie.Contains(filtru))
                {
                    string linie = $"{nume}  ({row["nume_categorie"]})";

                }
            }
        }
    }
}