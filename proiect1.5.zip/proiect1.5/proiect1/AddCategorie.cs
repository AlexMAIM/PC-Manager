﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect1
{
    public partial class AddCategorie : Form
    {
        public AddCategorie()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormStart frmStart = new FormStart();
            frmStart.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else
            {
                var conn = Utilities.OpenDbConnection();
                string query = "INSERT INTO Categorii (nume_categorie, descriere, data_creare, activ) VALUES (@nume_categorie, @descriere, @data_creare, @activ)";
                var cmd = new Microsoft.Data.SqlClient.SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_categorie", cmbNume.Text);
                cmd.Parameters.AddWithValue("@descriere", txtDesc.Text);
                cmd.Parameters.AddWithValue("@data_creare", dtpCreare.Value.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@activ", txtActiv.Text);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbCategorii(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var result = Utilities.ShowConfirmationDialog();
                if (result == DialogResult.No)
                    return;
                var conn = Utilities.OpenDbConnection();
                string query = "DELETE FROM Categorii WHERE id_categorie=@id_categorie";
                var cmd = new Microsoft.Data.SqlClient.SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id_categorie", categorieId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbCategorii(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else
            {
                var conn = Utilities.OpenDbConnection();
                string query = "UPDATE Categorii SET nume_categorie=@nume_categorie, descriere=@descriere, data_creare=@data_creare, activ=@activ WHERE id_categorie=@id_categorie";
                var cmd = new Microsoft.Data.SqlClient.SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_categorie", cmbNume.Text);
                cmd.Parameters.AddWithValue("@descriere", txtDesc.Text);
                cmd.Parameters.AddWithValue("@data_creare", dtpCreare.Value.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@activ", txtActiv.Text);
                cmd.Parameters.AddWithValue("@id_categorie", categorieId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbCategorii(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        int categorieId;

        public void FillCmbCategorii(ComboBox cmbTemp)
        {
            try
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT id_categorie, nume_categorie FROM Categorii ORDER BY nume_categorie";
                var cmd = new Microsoft.Data.SqlClient.SqlCommand(query, conn);
                var dt = Utilities.GetDataFromDb(conn, cmd);
                cmbTemp.DataSource = dt;
                cmbTemp.DisplayMember = "nume_categorie";
                cmbTemp.ValueMember = "id_categorie";
                cmbTemp.SelectedIndex = -1;
                cmbTemp.Text = "Selecteaza o categorie";
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private void cmbNume_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT * FROM Categorii WHERE id_categorie = @id_categorie";
                try
                {
                    categorieId = Convert.ToInt32(cmbNume.SelectedValue);
                    var cmd = new Microsoft.Data.SqlClient.SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id_categorie", categorieId);
                    var dt = Utilities.GetDataFromDb(conn, cmd);
                    if (dt.Rows.Count > 0)
                    {
                        txtDesc.Text = dt.Rows[0]["descriere"].ToString();
                        dtpCreare.Value = Convert.ToDateTime(dt.Rows[0]["data_creare"]);
                        txtActiv.Text = dt.Rows[0]["activ"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtpCreare_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtActiv_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillCmbCategorii(cmbNume);
            Utilities.ClearTextBoxes(this);
        }

        private void AddCategorie_Load(object sender, EventArgs e)
        {

        }
    }
}
