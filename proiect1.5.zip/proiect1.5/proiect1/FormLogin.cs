﻿using proiect1;
using Microsoft.Data.SqlClient;
using System.Data;

namespace proiect1
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
            //LoadFiles(dgvFiles);
            ThemeColor.LoadTheme(this);
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Utilities.OpenDbConnection();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            conn.Open();
            string login = "SELECT * FROM Utilizatori WHERE Nume= '" + txtUsername.Text + "' and Parola = '" + txtPassword.Text + "'";
            cmd = new SqlCommand(login, conn);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read() == true)
            {
                this.Hide();
                MessageBox.Show("Autentificare reușită!",
                "Bine ai venit",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                var f = new FormStart();
                f.Closed += (s, args) => this.Close();
                f.Show();
            }
            else
            {
                MessageBox.Show("Numele sau parola sunt invalide. Incearca din nou", "Conectare nereusita", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtUsername.Focus();
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            FormRegister frmReg = new FormRegister();
            frmReg.Show();
            this.Hide();
        }

        private void chkArataParola_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkArataParola.Checked;
        }
        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
