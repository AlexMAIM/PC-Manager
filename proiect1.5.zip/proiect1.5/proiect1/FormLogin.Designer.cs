﻿namespace proiect1
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            label1 = new Label();
            label2 = new Label();
            btnLogin = new Button();
            btnRegister = new Button();
            label3 = new Label();
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            panel1 = new Panel();
            chkArataParola = new CheckBox();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Coral;
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(3, 9);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 0;
            label1.Text = "Conectare";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Coral;
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(12, 103);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Parola";
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.SeaGreen;
            btnLogin.ForeColor = SystemColors.ControlLightLight;
            btnLogin.Location = new Point(54, 268);
            btnLogin.Margin = new Padding(1);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(115, 50);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "Conectează-te";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.LimeGreen;
            btnRegister.ForeColor = SystemColors.ControlLightLight;
            btnRegister.Location = new Point(39, 336);
            btnRegister.Margin = new Padding(1);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(144, 23);
            btnRegister.TabIndex = 3;
            btnRegister.Text = "Înregistrează-te";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Coral;
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(12, 53);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 4;
            label3.Text = "Utilizator";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(12, 71);
            txtUsername.MaxLength = 20;
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Utilizator";
            txtUsername.Size = new Size(204, 23);
            txtUsername.TabIndex = 0;
            txtUsername.TextChanged += txtUsername_TextChanged;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(12, 121);
            txtPassword.MaxLength = 25;
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Parola";
            txtPassword.Size = new Size(204, 23);
            txtPassword.TabIndex = 1;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.TextChanged += txtPassword_TextChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Coral;
            panel1.Controls.Add(chkArataParola);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnRegister);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(261, 404);
            panel1.TabIndex = 7;
            // 
            // chkArataParola
            // 
            chkArataParola.AutoSize = true;
            chkArataParola.ForeColor = Color.Cornsilk;
            chkArataParola.Location = new Point(126, 150);
            chkArataParola.Name = "chkArataParola";
            chkArataParola.Size = new Size(90, 19);
            chkArataParola.TabIndex = 4;
            chkArataParola.Text = "Arata Parola";
            chkArataParola.UseVisualStyleBackColor = true;
            chkArataParola.CheckedChanged += chkArataParola_CheckedChanged;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DimGray;
            panel2.BackgroundImage = (Image)resources.GetObject("panel2.BackgroundImage");
            panel2.Location = new Point(311, 0);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(382, 368);
            panel2.TabIndex = 9;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(786, 401);
            Controls.Add(panel2);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Controls.Add(panel1);
            Name = "FormLogin";
            Text = "Conectează-te";
            Load += FormLogin_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button btnLogin;
        private Button btnRegister;
        private Label label3;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Panel panel1;
        private Panel panel2;
        private CheckBox chkArataParola;
    }
}
