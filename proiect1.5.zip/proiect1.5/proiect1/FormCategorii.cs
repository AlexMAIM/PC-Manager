﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect1
{
    public partial class FormCategorii : Form
    {
        public FormCategorii()
        {
            InitializeComponent();
            IncarcaCategorii();  
            dataGridViewCategorii.CellFormatting += dataGridViewCategorii_CellFormatting;
        }

        private void IncarcaCategorii(string search = "")
        {
            using (SqlConnection conn = Utilities.OpenDbConnection())
            {
                try
                {
                    conn.Open();

                    string query = @"
                    SELECT 
                        id_categorie    AS ID,
                        nume_categorie  AS [Nume Categorie],
                        descriere       AS Descriere,
                        data_creare     AS [Data Creare],
                        activ           AS Activ
                    FROM Categorii
                    WHERE @search = '' 
                       OR nume_categorie LIKE '%' + @search + '%'
                       OR descriere     LIKE '%' + @search + '%'";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@search", search.Trim());

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            dataGridViewCategorii.DataSource = dt;

                            dataGridViewCategorii.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                            dataGridViewCategorii.RowHeadersVisible = false;
                            dataGridViewCategorii.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                            dataGridViewCategorii.ReadOnly = true;
                            dataGridViewCategorii.AllowUserToAddRows = false;

                            if (dataGridViewCategorii.Columns["ID"] != null)
                                dataGridViewCategorii.Columns["ID"].Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la încărcarea categoriilor:\n" + ex.Message);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();
            IncarcaCategorii(searchText);
        }

        private void dataGridViewCategorii_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewCategorii.Columns[e.ColumnIndex].Name == "Activ")
            {
                if (e.Value != null && Convert.ToBoolean(e.Value))
                {
                    e.CellStyle.ForeColor = Color.Green;
                    e.CellStyle.Font = new Font(dataGridViewCategorii.Font, FontStyle.Bold);
                }
                else
                {
                    e.CellStyle.ForeColor = Color.Red;
                }
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            AddCategorie frmAddCat = new AddCategorie();
            frmAddCat.Show();
            this.Hide();
        }

        private void FormCategorii_Load_1(object sender, EventArgs e)
        {

        }

        private void cmbSorteaza_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
