﻿
namespace proiect1
{
    partial class AddFavorite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnModify = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtCategorie = new TextBox();
            txtFavorit = new TextBox();
            cmbPiesa = new ComboBox();
            SuspendLayout();
            // 
            // btnModify
            // 
            btnModify.Location = new Point(136, 160);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(75, 23);
            btnModify.TabIndex = 0;
            btnModify.Text = "Modifică";
            btnModify.UseVisualStyleBackColor = true;
            btnModify.Click += btnModify_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Firebrick;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(31, 118);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 1;
            label1.Text = "Favorit";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Firebrick;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(31, 84);
            label2.Name = "label2";
            label2.Size = new Size(94, 15);
            label2.TabIndex = 2;
            label2.Text = "Nume Categorie";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Firebrick;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(31, 52);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 3;
            label3.Text = "Piesa";
            // 
            // txtCategorie
            // 
            txtCategorie.Location = new Point(136, 76);
            txtCategorie.Name = "txtCategorie";
            txtCategorie.ReadOnly = true;
            txtCategorie.Size = new Size(194, 23);
            txtCategorie.TabIndex = 5;
            txtCategorie.TextChanged += txtCategorie_TextChanged;
            // 
            // txtFavorit
            // 
            txtFavorit.Location = new Point(136, 110);
            txtFavorit.Name = "txtFavorit";
            txtFavorit.ReadOnly = true;
            txtFavorit.Size = new Size(111, 23);
            txtFavorit.TabIndex = 6;
            txtFavorit.TextChanged += txtFavorit_TextChanged;
            // 
            // cmbPiesa
            // 
            cmbPiesa.FormattingEnabled = true;
            cmbPiesa.Location = new Point(136, 44);
            cmbPiesa.Name = "cmbPiesa";
            cmbPiesa.Size = new Size(194, 23);
            cmbPiesa.TabIndex = 7;
            // 
            // AddFavorite
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Firebrick;
            ClientSize = new Size(411, 226);
            Controls.Add(cmbPiesa);
            Controls.Add(txtFavorit);
            Controls.Add(txtCategorie);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnModify);
            Name = "AddFavorite";
            Text = "AddFavorite";
            Load += AddFavorite_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnModify;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtPiesa;
        private TextBox txtCategorie;
        private TextBox txtFavorit;
        private ComboBox cmbPiesa;
    }
}