﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect1
{
    public partial class FormStart : Form
    {
        private static Button cmdCurrent;
        private static Random random;
        private static Form formActive;
        public FormStart()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.None;
            MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
        }

        private void FormStart_Load(object sender, EventArgs e)
        {
        }

        private void cmdClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cmdMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal) WindowState = FormWindowState.Maximized;
            else WindowState = FormWindowState.Normal;
        }

        private void cmdMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.dll", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.dll", EntryPoint = "SendMessage")]
        private extern static void SendMessage(IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panelTitle_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void cmdCategorii_Click(object sender, EventArgs e)
        {
            OpenForms(new FormCategorii(), sender);
        }

        private void cmdFavorite_Click(object sender, EventArgs e)
        {
            OpenForms(new FormFavorite(), sender);
        }

        private void cmdFurnizori_Click(object sender, EventArgs e)
        {
            OpenForms(new FormFurnizori(), sender);
        }

        private void cmdPiese_Click(object sender, EventArgs e)
        {
            OpenForms(new FormPiese(), sender);
        }

        private void OpenForms(Form childForm, object cmdCurrent)
        {
            if (formActive != null)
            {
                formActive.Close();
            }
            formActive = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormStart frmStart = new FormStart();
            frmStart.Show();
            this.Hide();
        }

        private void btnDisc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Te-ai deconectat cu succes!",
"Te mai așteptăm",
MessageBoxButtons.OK, MessageBoxIcon.Information);
            FormLogin frmLogin = new FormLogin();
            frmLogin.Show();
            this.Hide();
        }
    }
}

