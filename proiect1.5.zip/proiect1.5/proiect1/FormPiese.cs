﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;  

namespace proiect1
{
    public partial class FormPiese : Form
    {
        public FormPiese()
        {
            InitializeComponent();
            IncarcaPiese();
            dataGridView1.CellFormatting += dataGridView1_CellFormatting;
        }

        private void IncarcaPiese(string search = "")
        {
            SqlConnection conn = Utilities.OpenDbConnection();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                conn.Open();
                string query = @"SELECT 
                                    p.id_piesa AS ID,
                                    p.nume_piesa AS [Nume Piesă],
                                    p.pret AS [Preț],
                                    p.stoc AS Stoc,
                                    p.specificatii AS Specificații,
                                    c.nume_categorie AS Categorie
                                 FROM Piese p
                                 INNER JOIN Categorii c ON p.id_categorie = c.id_categorie
                                 WHERE (@search = '' OR p.nume_piesa LIKE '%' + @search + '%')
                                 ORDER BY p.nume_piesa";

                cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", search);
                da.SelectCommand = cmd;
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;

                if (dataGridView1.Columns["ID"] != null)
                    dataGridView1.Columns["ID"].Visible = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea pieselor: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }


        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Stoc" && e.Value != null)
            {
                int stoc = Convert.ToInt32(e.Value);
                if (stoc == 0)
                {
                    e.CellStyle.ForeColor = Color.Red;
                    e.CellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
                }
                else if (stoc <= 5)
                {
                    e.CellStyle.ForeColor = Color.Orange;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            AddPiese frmAddPiese = new AddPiese();
            frmAddPiese.Show();
            this.Hide();
        }

        private void FormPiese_Load(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            IncarcaPiese(txtSearch.Text.Trim());
        }
    }
}