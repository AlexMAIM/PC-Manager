﻿namespace proiect1
{
    partial class AddPiese
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddPiese));
            label1 = new Label();
            Pret = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnCancel = new Button();
            cmbNume = new ComboBox();
            txtPret = new TextBox();
            txtStoc = new TextBox();
            txtSpec = new TextBox();
            txtCategorie = new TextBox();
            txtFavorit = new TextBox();
            btnAdd = new Button();
            btnModify = new Button();
            btnDel = new Button();
            btnRefresh = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 21);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Nume";
            // 
            // Pret
            // 
            Pret.AutoSize = true;
            Pret.Location = new Point(12, 53);
            Pret.Name = "Pret";
            Pret.Size = new Size(28, 15);
            Pret.TabIndex = 1;
            Pret.Text = "Pret";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 89);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 2;
            label2.Text = "Stoc";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 119);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 3;
            label3.Text = "Specificatii";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 151);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 4;
            label4.Text = "Categorie";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 185);
            label5.Name = "label5";
            label5.Size = new Size(43, 15);
            label5.TabIndex = 5;
            label5.Text = "Favorit";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(343, 279);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 6;
            btnCancel.Text = "Anulare";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // cmbNume
            // 
            cmbNume.FormattingEnabled = true;
            cmbNume.Location = new Point(116, 18);
            cmbNume.Name = "cmbNume";
            cmbNume.Size = new Size(228, 23);
            cmbNume.TabIndex = 7;
            // 
            // txtPret
            // 
            txtPret.Location = new Point(116, 50);
            txtPret.Name = "txtPret";
            txtPret.Size = new Size(228, 23);
            txtPret.TabIndex = 8;
            // 
            // txtStoc
            // 
            txtStoc.Location = new Point(116, 86);
            txtStoc.Name = "txtStoc";
            txtStoc.Size = new Size(228, 23);
            txtStoc.TabIndex = 9;
            // 
            // txtSpec
            // 
            txtSpec.Location = new Point(116, 116);
            txtSpec.Name = "txtSpec";
            txtSpec.Size = new Size(228, 23);
            txtSpec.TabIndex = 10;
            // 
            // txtCategorie
            // 
            txtCategorie.Location = new Point(116, 148);
            txtCategorie.Name = "txtCategorie";
            txtCategorie.Size = new Size(228, 23);
            txtCategorie.TabIndex = 11;
            // 
            // txtFavorit
            // 
            txtFavorit.Location = new Point(116, 182);
            txtFavorit.Name = "txtFavorit";
            txtFavorit.Size = new Size(88, 23);
            txtFavorit.TabIndex = 12;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(12, 217);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 13;
            btnAdd.Text = "Adaugă";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnModify
            // 
            btnModify.Location = new Point(12, 246);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(75, 23);
            btnModify.TabIndex = 14;
            btnModify.Text = "Modifică";
            btnModify.UseVisualStyleBackColor = true;
            btnModify.Click += btnModify_Click;
            // 
            // btnDel
            // 
            btnDel.Location = new Point(12, 275);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(75, 23);
            btnDel.TabIndex = 15;
            btnDel.Text = "Șterge";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Image = (Image)resources.GetObject("btnRefresh.Image");
            btnRefresh.Location = new Point(391, 6);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(27, 30);
            btnRefresh.TabIndex = 16;
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // AddPiese
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSeaGreen;
            ClientSize = new Size(430, 314);
            Controls.Add(btnRefresh);
            Controls.Add(btnDel);
            Controls.Add(btnModify);
            Controls.Add(btnAdd);
            Controls.Add(txtFavorit);
            Controls.Add(txtCategorie);
            Controls.Add(txtSpec);
            Controls.Add(txtStoc);
            Controls.Add(txtPret);
            Controls.Add(cmbNume);
            Controls.Add(btnCancel);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Pret);
            Controls.Add(label1);
            Name = "AddPiese";
            Text = "Adăugare Piese";
            Load += AddPiese_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label Pret;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnCancel;
        private ComboBox cmbNume;
        private TextBox txtPret;
        private TextBox txtStoc;
        private TextBox txtSpec;
        private TextBox txtCategorie;
        private TextBox txtFavorit;
        private Button btnAdd;
        private Button btnModify;
        private Button btnDel;
        private Button btnRefresh;
    }
}