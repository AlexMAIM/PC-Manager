﻿namespace proiect1
{
    partial class FormRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtUsername = new TextBox();
            txtParola = new TextBox();
            btnRegister = new Button();
            btnCancel = new Button();
            label4 = new Label();
            label5 = new Label();
            txtCountry = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ControlText;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(88, 15);
            label1.TabIndex = 0;
            label1.Text = "Înregistrează-te";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(229, 59);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Nume";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(229, 120);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 2;
            label3.Text = "Parolă";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(149, 77);
            txtUsername.MaxLength = 20;
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Introdu un username";
            txtUsername.Size = new Size(200, 23);
            txtUsername.TabIndex = 3;
            txtUsername.TextChanged += txtUsername_TextChanged;
            // 
            // txtParola
            // 
            txtParola.Location = new Point(149, 138);
            txtParola.MaxLength = 25;
            txtParola.Name = "txtParola";
            txtParola.PlaceholderText = "Introdu o parolă";
            txtParola.Size = new Size(200, 23);
            txtParola.TabIndex = 4;
            txtParola.UseSystemPasswordChar = true;
            txtParola.TextChanged += txtParola_TextChanged;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.ForestGreen;
            btnRegister.Location = new Point(189, 303);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(105, 23);
            btnRegister.TabIndex = 5;
            btnRegister.Text = "Înregistrează-te";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.LightCoral;
            btnCancel.Location = new Point(441, 395);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(79, 25);
            btnCancel.TabIndex = 6;
            btnCancel.Text = "Anulează";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(213, 182);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 7;
            label4.Text = "Data nașterii";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(229, 238);
            label5.Name = "label5";
            label5.Size = new Size(29, 15);
            label5.TabIndex = 8;
            label5.Text = "Țară";
            // 
            // txtCountry
            // 
            txtCountry.Location = new Point(189, 256);
            txtCountry.MaxLength = 25;
            txtCountry.Name = "txtCountry";
            txtCountry.PlaceholderText = "Introdu o țară";
            txtCountry.Size = new Size(110, 23);
            txtCountry.TabIndex = 10;
            txtCountry.TextAlign = HorizontalAlignment.Center;
            txtCountry.TextChanged += txtCountry_TextChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(149, 200);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 11;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // FormRegister
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSalmon;
            ClientSize = new Size(532, 432);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtCountry);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(btnCancel);
            Controls.Add(btnRegister);
            Controls.Add(txtParola);
            Controls.Add(txtUsername);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormRegister";
            Text = "Înregistrare";
            Load += FormRegister_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtUsername;
        private TextBox txtParola;
        private Button btnRegister;
        private Button btnCancel;
        private Label label4;
        private Label label5;
        private TextBox txtCountry;
        private DateTimePicker dateTimePicker1;
    }
}