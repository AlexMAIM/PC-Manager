﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; 
namespace proiect1
{
    public partial class FormFavorite : Form
    {
        public FormFavorite()
        {
            InitializeComponent();
            IncarcaFavorite();
            dataGridView1.CellFormatting += dataGridView1_CellFormatting;
        }

        private void IncarcaFavorite(string search = "")
        {
            using (SqlConnection conn = Utilities.OpenDbConnection())
            {
                try
                {
                    conn.Open();

                    string query = @"
                    SELECT 
                        p.id_piesa           AS ID,
                        p.nume_piesa         AS [Nume Piesă],
                        p.pret               AS [Preț],
                        p.stoc               AS Stoc,
                        p.specificatii       AS Specificații,
                        c.nume_categorie     AS Categorie
                    FROM Piese p
                    INNER JOIN Categorii c ON p.id_categorie = c.id_categorie
                    WHERE p.favorit = 1
                      AND (@search = '' 
                        OR p.nume_piesa     LIKE '%' + @search + '%'
                        OR p.specificatii   LIKE '%' + @search + '%'
                        OR c.nume_categorie LIKE '%' + @search + '%')";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@search", search.Trim());

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dataGridView1.DataSource = dt;
                            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                            dataGridView1.RowHeadersVisible = false;
                            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                            dataGridView1.ReadOnly = true;
                            dataGridView1.AllowUserToAddRows = false;

                            if (dataGridView1.Columns["ID"] != null)
                                dataGridView1.Columns["ID"].Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la încărcarea pieselor favorite:\n" + ex.Message);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();
            IncarcaFavorite(searchText);
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Stoc" && e.Value != null)
            {
                int stoc = Convert.ToInt32(e.Value);
                if (stoc == 0)
                {
                    e.CellStyle.ForeColor = Color.Red;
                    e.CellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
                }
                else if (stoc <= 5)
                {
                    e.CellStyle.ForeColor = Color.Orange;
                }
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            AddFavorite frmaddfav = new AddFavorite();
            frmaddfav.Show();
            this.Hide();
        }

        private void FormFavorite_Load(object sender, EventArgs e)
        {

        }
    }
}