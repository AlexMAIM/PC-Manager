﻿namespace proiect1
{
    partial class FormStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStart));
            panelMenu = new Panel();
            btnDisc = new Button();
            cmdPiese = new Button();
            cmdFavorite = new Button();
            panelTitle = new Panel();
            btnHome = new Button();
            cmdFurnizori = new Button();
            cmdCategorii = new Button();
            panelLogo = new Panel();
            cmdClose = new Button();
            cmdMaximize = new Button();
            cmdMinimize = new Button();
            lblTitle = new Label();
            panel1 = new Panel();
            panelDesktop = new Panel();
            panelMenu.SuspendLayout();
            panelTitle.SuspendLayout();
            panelLogo.SuspendLayout();
            panelDesktop.SuspendLayout();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(255, 128, 0);
            panelMenu.Controls.Add(btnDisc);
            panelMenu.Controls.Add(cmdPiese);
            panelMenu.Controls.Add(cmdFavorite);
            panelMenu.Controls.Add(panelTitle);
            panelMenu.Controls.Add(cmdFurnizori);
            panelMenu.Controls.Add(cmdCategorii);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 0);
            panelMenu.Margin = new Padding(2);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(105, 545);
            panelMenu.TabIndex = 3;
            // 
            // btnDisc
            // 
            btnDisc.BackColor = Color.Brown;
            btnDisc.ForeColor = Color.WhiteSmoke;
            btnDisc.Location = new Point(12, 490);
            btnDisc.Name = "btnDisc";
            btnDisc.Size = new Size(81, 38);
            btnDisc.TabIndex = 8;
            btnDisc.Text = "Deconectează-te";
            btnDisc.UseVisualStyleBackColor = false;
            btnDisc.Click += btnDisc_Click;
            // 
            // cmdPiese
            // 
            cmdPiese.BackColor = Color.Transparent;
            cmdPiese.FlatStyle = FlatStyle.Flat;
            cmdPiese.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdPiese.ForeColor = Color.White;
            cmdPiese.Image = (Image)resources.GetObject("cmdPiese.Image");
            cmdPiese.ImageAlign = ContentAlignment.TopCenter;
            cmdPiese.Location = new Point(0, 337);
            cmdPiese.Margin = new Padding(2);
            cmdPiese.Name = "cmdPiese";
            cmdPiese.Size = new Size(105, 77);
            cmdPiese.TabIndex = 5;
            cmdPiese.Text = "Piese";
            cmdPiese.TextAlign = ContentAlignment.BottomCenter;
            cmdPiese.UseVisualStyleBackColor = false;
            cmdPiese.Click += cmdPiese_Click;
            // 
            // cmdFavorite
            // 
            cmdFavorite.BackColor = Color.Transparent;
            cmdFavorite.FlatStyle = FlatStyle.Flat;
            cmdFavorite.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdFavorite.ForeColor = Color.White;
            cmdFavorite.Image = (Image)resources.GetObject("cmdFavorite.Image");
            cmdFavorite.ImageAlign = ContentAlignment.TopCenter;
            cmdFavorite.Location = new Point(0, 139);
            cmdFavorite.Margin = new Padding(2);
            cmdFavorite.Name = "cmdFavorite";
            cmdFavorite.Size = new Size(105, 77);
            cmdFavorite.TabIndex = 7;
            cmdFavorite.Text = "Favorite";
            cmdFavorite.TextAlign = ContentAlignment.BottomCenter;
            cmdFavorite.UseVisualStyleBackColor = false;
            cmdFavorite.Click += cmdFavorite_Click;
            // 
            // panelTitle
            // 
            panelTitle.BackColor = Color.PeachPuff;
            panelTitle.Controls.Add(btnHome);
            panelTitle.Dock = DockStyle.Top;
            panelTitle.Location = new Point(0, 0);
            panelTitle.Margin = new Padding(2);
            panelTitle.Name = "panelTitle";
            panelTitle.Size = new Size(105, 36);
            panelTitle.TabIndex = 4;
            panelTitle.MouseDown += panelTitle_MouseDown;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.PeachPuff;
            btnHome.BackgroundImage = (Image)resources.GetObject("btnHome.BackgroundImage");
            btnHome.Location = new Point(21, 0);
            btnHome.Margin = new Padding(0);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(63, 37);
            btnHome.TabIndex = 0;
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // cmdFurnizori
            // 
            cmdFurnizori.BackColor = Color.Transparent;
            cmdFurnizori.FlatStyle = FlatStyle.Flat;
            cmdFurnizori.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdFurnizori.ForeColor = Color.White;
            cmdFurnizori.Image = (Image)resources.GetObject("cmdFurnizori.Image");
            cmdFurnizori.ImageAlign = ContentAlignment.TopCenter;
            cmdFurnizori.Location = new Point(0, 239);
            cmdFurnizori.Margin = new Padding(2);
            cmdFurnizori.Name = "cmdFurnizori";
            cmdFurnizori.Size = new Size(105, 77);
            cmdFurnizori.TabIndex = 6;
            cmdFurnizori.Text = "Furnizori";
            cmdFurnizori.TextAlign = ContentAlignment.BottomCenter;
            cmdFurnizori.UseVisualStyleBackColor = false;
            cmdFurnizori.Click += cmdFurnizori_Click;
            // 
            // cmdCategorii
            // 
            cmdCategorii.BackColor = Color.Transparent;
            cmdCategorii.FlatStyle = FlatStyle.Flat;
            cmdCategorii.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmdCategorii.ForeColor = Color.White;
            cmdCategorii.Image = (Image)resources.GetObject("cmdCategorii.Image");
            cmdCategorii.ImageAlign = ContentAlignment.TopCenter;
            cmdCategorii.Location = new Point(0, 40);
            cmdCategorii.Margin = new Padding(2);
            cmdCategorii.Name = "cmdCategorii";
            cmdCategorii.Size = new Size(105, 77);
            cmdCategorii.TabIndex = 1;
            cmdCategorii.Text = "Categorii";
            cmdCategorii.TextAlign = ContentAlignment.BottomCenter;
            cmdCategorii.UseVisualStyleBackColor = false;
            cmdCategorii.Click += cmdCategorii_Click;
            // 
            // panelLogo
            // 
            panelLogo.BackColor = Color.FromArgb(255, 128, 0);
            panelLogo.Controls.Add(cmdClose);
            panelLogo.Controls.Add(cmdMaximize);
            panelLogo.Controls.Add(cmdMinimize);
            panelLogo.Controls.Add(lblTitle);
            panelLogo.Dock = DockStyle.Top;
            panelLogo.Location = new Point(105, 0);
            panelLogo.Margin = new Padding(2);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new Size(892, 36);
            panelLogo.TabIndex = 4;
            // 
            // cmdClose
            // 
            cmdClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cmdClose.BackColor = Color.Transparent;
            cmdClose.FlatStyle = FlatStyle.Flat;
            cmdClose.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            cmdClose.ForeColor = Color.White;
            cmdClose.Location = new Point(850, 0);
            cmdClose.Margin = new Padding(2);
            cmdClose.Name = "cmdClose";
            cmdClose.Size = new Size(42, 36);
            cmdClose.TabIndex = 0;
            cmdClose.Text = "X";
            cmdClose.TextAlign = ContentAlignment.TopCenter;
            cmdClose.UseVisualStyleBackColor = false;
            cmdClose.Click += cmdClose_Click;
            // 
            // cmdMaximize
            // 
            cmdMaximize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cmdMaximize.BackColor = Color.Transparent;
            cmdMaximize.FlatStyle = FlatStyle.Flat;
            cmdMaximize.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            cmdMaximize.ForeColor = Color.White;
            cmdMaximize.Location = new Point(805, 0);
            cmdMaximize.Margin = new Padding(2);
            cmdMaximize.Name = "cmdMaximize";
            cmdMaximize.Size = new Size(42, 39);
            cmdMaximize.TabIndex = 1;
            cmdMaximize.Text = "O";
            cmdMaximize.TextAlign = ContentAlignment.TopCenter;
            cmdMaximize.UseVisualStyleBackColor = false;
            cmdMaximize.Click += cmdMaximize_Click;
            // 
            // cmdMinimize
            // 
            cmdMinimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cmdMinimize.BackColor = Color.Transparent;
            cmdMinimize.FlatStyle = FlatStyle.Flat;
            cmdMinimize.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            cmdMinimize.ForeColor = Color.White;
            cmdMinimize.Location = new Point(759, 0);
            cmdMinimize.Margin = new Padding(2);
            cmdMinimize.Name = "cmdMinimize";
            cmdMinimize.Size = new Size(42, 39);
            cmdMinimize.TabIndex = 2;
            cmdMinimize.Text = "-";
            cmdMinimize.TextAlign = ContentAlignment.TopCenter;
            cmdMinimize.UseVisualStyleBackColor = false;
            cmdMinimize.Click += cmdMinimize_Click;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.BackColor = Color.Transparent;
            lblTitle.Font = new Font("Segoe UI", 20F);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(4, 0);
            lblTitle.Margin = new Padding(2, 0, 2, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(85, 37);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Acasă";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Click += lblTitle_Click;
            // 
            // panel1
            // 
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.Location = new Point(337, 103);
            panel1.Name = "panel1";
            panel1.Size = new Size(416, 385);
            panel1.TabIndex = 5;
            // 
            // panelDesktop
            // 
            panelDesktop.BackColor = Color.PeachPuff;
            panelDesktop.Controls.Add(panel1);
            panelDesktop.Controls.Add(panelLogo);
            panelDesktop.Controls.Add(panelMenu);
            panelDesktop.Dock = DockStyle.Top;
            panelDesktop.ForeColor = Color.Crimson;
            panelDesktop.Location = new Point(0, 0);
            panelDesktop.Margin = new Padding(2);
            panelDesktop.Name = "panelDesktop";
            panelDesktop.Size = new Size(997, 545);
            panelDesktop.TabIndex = 3;
            panelDesktop.Paint += panelDesktop_Paint;
            // 
            // FormStart
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(997, 540);
            Controls.Add(panelDesktop);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(2);
            Name = "FormStart";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pagină Acasă";
            Load += FormStart_Load;
            panelMenu.ResumeLayout(false);
            panelTitle.ResumeLayout(false);
            panelLogo.ResumeLayout(false);
            panelLogo.PerformLayout();
            panelDesktop.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenu;
        private Button cmdPiese;
        private Button cmdFavorite;
        private Panel panelTitle;
        private Button btnHome;
        private Button cmdFurnizori;
        private Button cmdCategorii;
        private Panel panelLogo;
        private Button cmdClose;
        private Button cmdMaximize;
        private Button cmdMinimize;
        private Label lblTitle;
        private Panel panel1;
        private Panel panelDesktop;
        private Button btnDisc;
    }
}