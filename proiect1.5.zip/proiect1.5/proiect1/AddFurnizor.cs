﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace proiect1
{
    public partial class AddFurnizor : Form
    {
        private int furnizorId;

        public AddFurnizor()
        {
            InitializeComponent();
            FillCmbFurnizori(cmbNume);
            cmbNume.SelectedIndexChanged += cmbNume_SelectedIndexChanged;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormStart frmStart = new FormStart();
            frmStart.Show();
            this.Hide();
        }

        private void btnAdauga_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else
            {
                var conn = Utilities.OpenDbConnection();
                string query = "INSERT INTO Furnizori (nume_furnizor, oras, adresa, telefon, email, cui, data_inregistrare, rating) VALUES (@nume_furnizor, @oras, @adresa, @telefon, @email, @cui, @data_inregistrare, @rating)";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_furnizor", cmbNume.Text);
                cmd.Parameters.AddWithValue("@oras", txtOras.Text);
                cmd.Parameters.AddWithValue("@adresa", txtAdresa.Text);
                cmd.Parameters.AddWithValue("@telefon", txtTelefon.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@cui", txtCui.Text);
                cmd.Parameters.AddWithValue("@data_inregistrare", dtpInregistrare.Value.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@rating", txtRating.Text);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbFurnizori(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else if (cmbNume.SelectedIndex > -1)
            {
                var conn = Utilities.OpenDbConnection();
                string query = "UPDATE Furnizori SET nume_furnizor=@nume_furnizor, oras=@oras, adresa=@adresa, telefon=@telefon, email=@email, cui=@cui, data_inregistrare=@data_inregistrare, rating=@rating WHERE id_furnizor=@id_furnizor";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_furnizor", cmbNume.Text);
                cmd.Parameters.AddWithValue("@oras", txtOras.Text);
                cmd.Parameters.AddWithValue("@adresa", txtAdresa.Text);
                cmd.Parameters.AddWithValue("@telefon", txtTelefon.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@cui", txtCui.Text);
                cmd.Parameters.AddWithValue("@data_inregistrare", dtpInregistrare.Value.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@rating", txtRating.Text);
                cmd.Parameters.AddWithValue("@id_furnizor", furnizorId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbFurnizori(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var result = Utilities.ShowConfirmationDialog();
                if (result == DialogResult.No)
                    return;
                var conn = Utilities.OpenDbConnection();
                string query = "DELETE FROM Furnizori WHERE id_furnizor=@id_furnizor";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id_furnizor", furnizorId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbFurnizori(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillCmbFurnizori(cmbNume);
            Utilities.ClearTextBoxes(this);
        }

        private void FillCmbFurnizori(ComboBox cmbTemp)
        {
            try
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT id_furnizor, nume_furnizor FROM Furnizori ORDER BY nume_furnizor";
                var cmd = new SqlCommand(query, conn);
                var dt = Utilities.GetDataFromDb(conn, cmd);
                cmbTemp.DataSource = dt;
                cmbTemp.DisplayMember = "nume_furnizor";
                cmbTemp.ValueMember = "id_furnizor";
                cmbTemp.SelectedIndex = -1;
                cmbTemp.Text = "Selecteaza un furnizor";
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private void cmbNume_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT * FROM Furnizori WHERE id_furnizor = @id_furnizor";
                try
                {
                    furnizorId = Convert.ToInt32(cmbNume.SelectedValue);
                    var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id_furnizor", furnizorId);
                    var dt = Utilities.GetDataFromDb(conn, cmd);
                    if (dt.Rows.Count > 0)
                    {
                        txtOras.Text = dt.Rows[0]["oras"].ToString();
                        txtAdresa.Text = dt.Rows[0]["adresa"].ToString();
                        txtTelefon.Text = dt.Rows[0]["telefon"].ToString();
                        txtEmail.Text = dt.Rows[0]["email"].ToString();
                        txtCui.Text = dt.Rows[0]["cui"].ToString();
                        dtpInregistrare.Value = Convert.ToDateTime(dt.Rows[0]["data_inregistrare"]);
                        txtRating.Text = dt.Rows[0]["rating"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void AddFurnizor_Load(object sender, EventArgs e)
        {

        }
    }
}
