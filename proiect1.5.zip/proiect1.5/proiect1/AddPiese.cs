﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace proiect1
{
    public partial class AddPiese : Form
    {
        private int piesaId;

        public AddPiese()
        {
            InitializeComponent();
            FillCmbPiese(cmbNume);
            cmbNume.SelectedIndexChanged += cmbNume_SelectedIndexChanged;
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else
            {
                var conn = Utilities.OpenDbConnection();
                string query = "INSERT INTO Piese (nume_piesa, pret, stoc, specificatii, id_categorie, favorit) VALUES (@nume_piesa, @pret, @stoc, @specificatii, @id_categorie, @favorit)";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_piesa", cmbNume.Text);
                cmd.Parameters.AddWithValue("@pret", txtPret.Text);
                cmd.Parameters.AddWithValue("@stoc", txtStoc.Text);
                cmd.Parameters.AddWithValue("@specificatii", txtSpec.Text);
                cmd.Parameters.AddWithValue("@id_categorie", GetCategorieId(txtCategorie.Text));
                cmd.Parameters.AddWithValue("@favorit", txtFavorit.Text == "1" || txtFavorit.Text.ToLower() == "da" ? 1 : 0);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbPiese(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (!Utilities.ValidateTextBoxes(this))
            {
                Utilities.ShowErrorMessage();
            }
            else if (cmbNume.SelectedIndex > -1)
            {
                var conn = Utilities.OpenDbConnection();
                string query = "UPDATE Piese SET nume_piesa=@nume_piesa, pret=@pret, stoc=@stoc, specificatii=@specificatii, id_categorie=@id_categorie, favorit=@favorit WHERE id_piesa=@id_piesa";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nume_piesa", cmbNume.Text);
                cmd.Parameters.AddWithValue("@pret", txtPret.Text);
                cmd.Parameters.AddWithValue("@stoc", txtStoc.Text);
                cmd.Parameters.AddWithValue("@specificatii", txtSpec.Text);
                cmd.Parameters.AddWithValue("@id_categorie", GetCategorieId(txtCategorie.Text));
                cmd.Parameters.AddWithValue("@favorit", txtFavorit.Text == "1" || txtFavorit.Text.ToLower() == "da" ? 1 : 0);
                cmd.Parameters.AddWithValue("@id_piesa", piesaId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbPiese(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var result = Utilities.ShowConfirmationDialog();
                if (result == DialogResult.No)
                    return;
                var conn = Utilities.OpenDbConnection();
                string query = "DELETE FROM Piese WHERE id_piesa=@id_piesa";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id_piesa", piesaId);
                Utilities.WriteDataToDb(conn, cmd);
                FillCmbPiese(cmbNume);
                Utilities.ClearTextBoxes(this);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillCmbPiese(cmbNume);
            Utilities.ClearTextBoxes(this);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormStart frmStart = new FormStart();
            frmStart.Show();
            this.Hide();
        }

        private void FillCmbPiese(ComboBox cmbTemp)
        {
            try
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT id_piesa, nume_piesa FROM Piese ORDER BY nume_piesa";
                var cmd = new SqlCommand(query, conn);
                var dt = Utilities.GetDataFromDb(conn, cmd);
                cmbTemp.DataSource = dt;
                cmbTemp.DisplayMember = "nume_piesa";
                cmbTemp.ValueMember = "id_piesa";
                cmbTemp.SelectedIndex = -1;
                cmbTemp.Text = "Selecteaza o piesa";
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private void cmbNume_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNume.SelectedIndex > -1)
            {
                var conn = Utilities.OpenDbConnection();
                string query = "SELECT * FROM Piese WHERE id_piesa = @id_piesa";
                try
                {
                    piesaId = Convert.ToInt32(cmbNume.SelectedValue);
                    var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id_piesa", piesaId);
                    var dt = Utilities.GetDataFromDb(conn, cmd);
                    if (dt.Rows.Count > 0)
                    {
                        txtPret.Text = dt.Rows[0]["pret"].ToString();
                        txtStoc.Text = dt.Rows[0]["stoc"].ToString();
                        txtSpec.Text = dt.Rows[0]["specificatii"].ToString();
                        txtCategorie.Text = dt.Rows[0]["id_categorie"].ToString();
                        txtFavorit.Text = (Convert.ToBoolean(dt.Rows[0]["favorit"]) ? "Da" : "Nu");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private int GetCategorieId(string categorieText)
        {
            int id;
            if (int.TryParse(categorieText, out id))
                return id;
            var conn = Utilities.OpenDbConnection();
            string query = "SELECT id_categorie FROM Categorii WHERE nume_categorie = @nume_categorie";
            var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@nume_categorie", categorieText);
            var dt = Utilities.GetDataFromDb(conn, cmd);
            if (dt.Rows.Count > 0)
                return Convert.ToInt32(dt.Rows[0]["id_categorie"]);
            return -1;
        }

        private void AddPiese_Load(object sender, EventArgs e)
        {

        }
    }
}
