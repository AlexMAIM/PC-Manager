﻿using proiect1;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect1
{
    public partial class FormRegister : Form
    {

        string username, password, datanast, country;
        public FormRegister()
        {
            InitializeComponent();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            username = txtUsername.Text;
        }

        private void txtParola_TextChanged(object sender, EventArgs e)
        {
            password = txtParola.Text;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void txtCountry_TextChanged(object sender, EventArgs e)
        {
            country = txtCountry.Text;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Utilities.OpenDbConnection();
            string query = "INSERT into Utilizatori (Nume, Parola, data_nastere, tara)" + " VALUES(@username, @password, @datanast, @country); ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@datanast", datanast = dateTimePicker1.Value.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@country", country);
            Utilities.WriteDataToDb(conn, cmd);
            Utilities.ClearTextBoxes(this);
            FormLogin frmLog = new FormLogin();
            frmLog.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormLogin frmLog = new FormLogin();
            frmLog.Show();
            this.Hide();
        }

        private void FormRegister_Load(object sender, EventArgs e)
        {

        }
    }
}
